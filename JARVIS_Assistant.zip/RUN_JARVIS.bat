@echo off
REM ============================================================
REM  RUN_JARVIS.bat
REM  This is the ONE file to double-click to start JARVIS.
REM  It simply hands off to jarvis\Start_JARVIS.bat, which does
REM  the actual first-time setup (creates a private environment,
REM  installs required packages) and then launches the app in
REM  your browser. See jarvis\README.md for details.
REM ============================================================
cd /d "%~dp0jarvis"
call Start_JARVIS.bat
